
import React from 'react';
import '../styles/categories.css'; // 

const Categories = () => {
  return (
    <div className="categories-container">
      <div className="category">
        category1
      </div>
      <div className="category">
        category2
      </div>
      <div className="category">
        category3
      </div>
      <div className="category">
        category4
      </div>
    </div>
  );
}

export default Categories;
